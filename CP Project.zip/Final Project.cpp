#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <iomanip>
#include <sstream>

using namespace std;

const int MAX_COWS = 100;

struct Cow {
    int id;
    string name;
    float milkProduced;
    float milkSold;
    float feedIntake;
    float profit;
    string healthStatus;
    string vaccinationDate;
    string milkQuality;
};

Cow cows[MAX_COWS];
int cowCount = 0;
bool isAdmin = false;

float calculateProfit(float milkSold) {
    float pricePerLiter = 125;
    float costPerLiter = 75;
    return (milkSold * pricePerLiter) - (milkSold * costPerLiter);
}

void toLowerCase(string& str) {
    for (int i = 0; i < str.length(); i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') {
            str[i] = str[i] + 32;
        }
    }
}

void sortCowsById() {
    for (int i = 0; i < cowCount - 1; i++) {
        for (int j = 0; j < cowCount - i - 1; j++) {
            if (cows[j].id > cows[j + 1].id) {
                Cow temp = cows[j];
                cows[j] = cows[j + 1];
                cows[j + 1] = temp;
            }
        }
    }
}

void saveToFile() {
    ofstream file("cow_data.txt");
    for (int i = 0; i < cowCount; i++) {
        file << cows[i].id << "," << cows[i].name << "," << cows[i].milkProduced << "," << cows[i].milkSold << ","
             << cows[i].feedIntake << "," << cows[i].profit << "," << cows[i].healthStatus << ","
             << cows[i].vaccinationDate << "," << cows[i].milkQuality << "\n";
    }
    file.close();
}

void loadFromFile() {
    ifstream file("cow_data.txt");
    string line;
    cowCount = 0;

    while (getline(file, line) && cowCount < MAX_COWS) {
        stringstream ss(line);
        Cow& cow = cows[cowCount];
        string field;

        getline(ss, field, ','); cow.id = atoi(field.c_str());
        getline(ss, cow.name, ',');
        getline(ss, field, ','); cow.milkProduced = atof(field.c_str());
        getline(ss, field, ','); cow.milkSold = atof(field.c_str());
        getline(ss, field, ','); cow.feedIntake = atof(field.c_str());
        getline(ss, field, ','); cow.profit = atof(field.c_str());
        getline(ss, cow.healthStatus, ',');
        getline(ss, cow.vaccinationDate, ',');
        getline(ss, cow.milkQuality);

        cowCount++;
    }

    file.close();
    sortCowsById();
}

void login() {
    string username, password;
    cout << "=== Dairy Farm Login ===\n";
    cout << "Username: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    if (username == "admin" && password == "1234") {
        isAdmin = true;
        cout << "Login successful. Welcome, Admin!\n";
    } else if (username == "view" && password == "1234") {
        isAdmin = false;
        cout << "Login successful. Welcome, Viewer!\n";
    } else {
        cout << "Invalid credentials. Exiting...\n";
        exit(0);
    }
}

void addCow() {
    if (cowCount >= MAX_COWS) {
        cout << "Maximum cow limit reached.\n";
        return;
    }

    Cow& cow = cows[cowCount];
    cout << "Enter cow ID: "; cin >> cow.id;
    cout << "Enter cow name: "; cin >> ws; getline(cin, cow.name);
    cout << "Enter milk produced (liters): "; cin >> cow.milkProduced;
    cout << "Enter milk sold (liters): "; cin >> cow.milkSold;
    cout << "Enter feed intake (kg): "; cin >> cow.feedIntake;
    cout << "Enter health status (Good/Sick): "; cin >> cow.healthStatus;
    cout << "Enter last vaccination date (YYYY-MM-DD): "; cin >> cow.vaccinationDate;
    cout << "Enter milk quality (A/B/C): "; cin >> cow.milkQuality;

    cow.profit = calculateProfit(cow.milkSold);
    cowCount++;
    sortCowsById();
    cout << "Cow added successfully.\n";
}

void viewCowDetails(Cow& cow) {
    cout << "ID: " << cow.id
         << ", Name: " << cow.name
         << ", Milk Produced: " << cow.milkProduced << " L"
         << ", Milk Sold: " << cow.milkSold << " L"
         << ", Feed: " << cow.feedIntake << " kg"
         << ", Profit: Rs. " << fixed << setprecision(2) << cow.profit
         << ", Health: " << cow.healthStatus
         << ", Last Vaccination: " << cow.vaccinationDate
         << ", Quality: " << cow.milkQuality << endl;
}

void viewCows() {
    if (cowCount == 0) {
        cout << "No records found.\n";
        return;
    }

    cout << "\n--- Cow Records ---\n";
    for (int i = 0; i < cowCount; i++) {
        viewCowDetails(cows[i]);
    }
}

void updateCow() {
    int id;
    cout << "Enter cow ID to update: ";
    cin >> id;

    for (int i = 0; i < cowCount; i++) {
        if (cows[i].id == id) {
            Cow& cow = cows[i];
            cout << "Enter new name: "; cin >> ws; getline(cin, cow.name);
            cout << "Enter new milk produced: "; cin >> cow.milkProduced;
            cout << "Enter new milk sold: "; cin >> cow.milkSold;
            cout << "Enter feed intake: "; cin >> cow.feedIntake;
            cout << "Enter health status: "; cin >> cow.healthStatus;
            cout << "Enter last vaccination date: "; cin >> cow.vaccinationDate;
            cout << "Enter milk quality: "; cin >> cow.milkQuality;
            cow.profit = calculateProfit(cow.milkSold);
            cout << "Record updated.\n";
            return;
        }
    }
    cout << "Cow ID not found.\n";
}

void deleteCow() {
    int id;
    cout << "Enter cow ID to delete: ";
    cin >> id;

    for (int i = 0; i < cowCount; i++) {
        if (cows[i].id == id) {
            for (int j = i; j < cowCount - 1; j++) {
                cows[j] = cows[j + 1];
            }
            cowCount--;
            cout << "Cow deleted.\n";
            return;
        }
    }
    cout << "Cow not found.\n";
}

void searchCow() {
    int option;
    cout << "Search by: 1. ID  2. Name\nEnter choice: ";
    cin >> option;

    if (option == 1) {
        int id;
        cout << "Enter ID: ";
        cin >> id;
        for (int i = 0; i < cowCount; i++) {
            if (cows[i].id == id) {
                cout << "Cow found:\n";
                viewCowDetails(cows[i]);
                return;
            }
        }
    } else if (option == 2) {
        string name;
        cout << "Enter name: "; cin >> ws; getline(cin, name);
        string searchName = name;
        toLowerCase(searchName);

        for (int i = 0; i < cowCount; i++) {
            string cowName = cows[i].name;
            toLowerCase(cowName);
            if (cowName == searchName) {
                cout << "Cow found:\n";
                viewCowDetails(cows[i]);
                return;
            }
        }
    }

    cout << "Cow not found.\n";
}

void generateReport() {
    float totalProduced = 0, totalSold = 0, totalProfit = 0;
    for (int i = 0; i < cowCount; i++) {
        totalProduced += cows[i].milkProduced;
        totalSold += cows[i].milkSold;
        totalProfit += cows[i].profit;
    }

    cout << "\n--- Milk Production Report ---\n";
    cout << "Total Produced: " << totalProduced << " L\n";
    cout << "Total Sold: " << totalSold << " L\n";
    cout << "Average Produced: " << (cowCount ? totalProduced / cowCount : 0) << " L\n";
    cout << "Total Profit: Rs. " << totalProfit << "\n";
}

void analyzeFeedEfficiency() {
    cout << "\n--- Feed Efficiency (Milk Produced per kg Feed) ---\n";
    for (int i = 0; i < cowCount; i++) {
        float efficiency = cows[i].milkProduced / (cows[i].feedIntake + 0.01);
        cout << "Cow " << cows[i].name << " - Efficiency: " << fixed << setprecision(2) << efficiency << " L/kg\n";
    }
}

void menu() {
    int choice;
    do {
        cout << "\n==== Dairy Farm Management ====\n";
        if (isAdmin) {
            cout << "1. Add Cow Record\n";
            cout << "2. View Cow Records\n";
            cout << "3. Update Cow Record\n";
            cout << "4. Delete Cow Record\n";
            cout << "5. Search Cow\n";
            cout << "6. Generate Milk Report\n";
            cout << "7. Feed Efficiency Analysis\n";
            cout << "8. Save and Exit\n";
        } else {
            cout << "1. View Cow Records\n";
            cout << "2. Search Cow\n";
            cout << "3. Generate Milk Report\n";
            cout << "4. Feed Efficiency Analysis\n";
            cout << "5. Exit\n";
        }

        cout << "Enter your choice: ";
        cin >> choice;

        if (isAdmin) {
            switch (choice) {
                case 1: addCow(); break;
                case 2: viewCows(); break;
                case 3: updateCow(); break;
                case 4: deleteCow(); break;
                case 5: searchCow(); break;
                case 6: generateReport(); break;
                case 7: analyzeFeedEfficiency(); break;
                case 8:
                    saveToFile();
                    cout << "Data saved. Exiting...\n";
                    break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } else {
            switch (choice) {
                case 1: viewCows(); break;
                case 2: searchCow(); break;
                case 3: generateReport(); break;
                case 4: analyzeFeedEfficiency(); break;
                case 5: cout << "Exiting...\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        }
    } while ((isAdmin && choice != 8) || (!isAdmin && choice != 5));
}

int main() {
    login();
    loadFromFile();
    menu();
    saveToFile();
    return 0;
}

